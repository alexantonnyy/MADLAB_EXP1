package com.example.mad_pwa_exp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
