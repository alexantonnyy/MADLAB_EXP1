# Experiment no 1:  First Flutter App

To design a basic layout of Flutter App using Scaffold widget (Snack-Bar, Bottom-Navigation-Bar, Floating-Action-Button, App-Bar)
